
function toggleWindow(windowId) {
  const windowElement = document.getElementById(windowId);
  windowElement.style.display = (windowElement.style.display === 'none' || windowElement.style.display === '') ? 'flex' : 'none';
}

function closeWindow(windowId) {
  document.getElementById(windowId).style.display = 'none';
}

function changeBackground(color) {
  document.body.style.backgroundColor = color;
}
